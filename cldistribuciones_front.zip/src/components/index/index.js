import React from 'react';

export default class inicio extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() { 
        return ( 
            <h1 style={{marginTop: 300}}> <br/>Página de Inicio</h1>
         );
    }
}
 
