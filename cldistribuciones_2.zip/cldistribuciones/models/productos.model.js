const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ProductosSchema = new Schema({
    id_producto:{type: Number, required: true, max:20},
    material:{type: String, required: true, max:150},
    descripcion:{type: String, required: true, max:300},
    precio:{type: Number, required: true, max:90000000},
    unidades:{type: Number, required: true, max:15},
    categoria:{type: String, required: true, max:70},
    tiempoentrega:{type: String, required:false, max:100}
});

module.exports = mongoose.model("productos", ProductosSchema);