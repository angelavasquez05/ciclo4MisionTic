import React from 'react';
import BCarousel from '../carousel/Carousel';


export default class inicio extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        return (
            <div>
                <h1 style={{ marginTop: 50 }}> <br />BIENVENIDOS</h1>
                <BCarousel />                
            </div>

        );
    }
}

