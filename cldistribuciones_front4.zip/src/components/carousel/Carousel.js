import React from 'react';
import { Carousel } from 'react-bootstrap';
import './Carousel.css';

export default function BCarousel() {
    return (
        <div>
            <Carousel>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="./images/parque-gorila.jpeg"
                        alt="slide 1"
                    />
                    <Carousel.Caption>
                        <h3>Parque Gorila</h3>
                    </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="./images/parque-importado.jpeg"
                        alt="slide 2"
                    />

                    <Carousel.Caption>
                        <h3>Parque Importado</h3>
                    </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="./images/parque-importado2.jpeg"
                        alt="slide 3"
                    />

                    <Carousel.Caption>
                        <h3>Parque Importado</h3>
                    </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="./images/parque-madera.jpeg"
                        alt="slide 4"
                    />
                    <Carousel.Caption>
                        <h3>Parque Madera</h3>
                    </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="./images/parque-metal.jpeg"
                        alt="slide 5"
                    />
                    <Carousel.Caption>
                        <h3>Parque Metal</h3>
                    </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="./images/parque-pirata.jpg"
                        alt="slide 6"
                    />
                    <Carousel.Caption>
                        <h3>Parque Pirata</h3>
                    </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="./images/parque-pulpo.jpeg"
                        alt="slide 7"
                    />
                    <Carousel.Caption>
                        <h3>Parque Pulpo</h3>
                    </Carousel.Caption>
                </Carousel.Item>
            </Carousel>
        </div>
    )
}



